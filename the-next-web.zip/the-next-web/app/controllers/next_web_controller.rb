class NextWebController < ApplicationController
  def home
  end
end
