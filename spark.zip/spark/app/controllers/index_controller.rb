class IndexController < ApplicationController
  def home
  end
end
